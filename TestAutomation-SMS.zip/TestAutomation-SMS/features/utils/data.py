class STB:
    valid_STB = "123STB"


class Add_Customer:
    Tittle_name = "Miss"
    First_name = "Sushmitha"
    last_Name = "Sankar"
    PinCode = "636119"
    password = "Testingteam12@"


class Add_STB:

    Chip_ID = "3690000004"


class payment_data:

    remarks = "Test Automation"
    amount = "100"
    ReceiptNo = "123456"
